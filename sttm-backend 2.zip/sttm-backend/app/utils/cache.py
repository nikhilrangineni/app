import json
import os
import hashlib
from typing import List, Dict

LINEAGE_CACHE_FILE = "lineage_cache.json"
HASHES_CACHE_FILE = "file_hashes.json"


# ----------- Lineage Cache -----------

def load_lineage_cache() -> dict:
    if not os.path.exists(LINEAGE_CACHE_FILE):
        return {}
    with open(LINEAGE_CACHE_FILE, "r") as f:
        return json.load(f)


def save_lineage_cache(cache: dict):
    with open(LINEAGE_CACHE_FILE, "w") as f:
        json.dump(cache, f, indent=2)


def get_cached_lineage(table_name: str):
    cache = load_lineage_cache()
    return cache.get(table_name.lower())


def add_to_cache(target: str, sources: List[Dict]):
    cache = load_lineage_cache()
    cache[target.lower()] = {
        "sources": sources
    }
    save_lineage_cache(cache)


# ----------- File Hash Cache -----------

def _get_file_hash(path: str) -> str:
    hasher = hashlib.md5()
    with open(path, "rb") as f:
        content = f.read()
        hasher.update(content)
    return hasher.hexdigest()


def load_hash_cache() -> dict:
    if not os.path.exists(HASHES_CACHE_FILE):
        return {}
    with open(HASHES_CACHE_FILE, "r") as f:
        return json.load(f)


def save_hash_cache(cache: dict):
    with open(HASHES_CACHE_FILE, "w") as f:
        json.dump(cache, f, indent=2)


def is_file_changed(local_path: str, blob_name: str) -> bool:
    hash_cache = load_hash_cache()
    new_hash = _get_file_hash(local_path)
    old_hash = hash_cache.get(blob_name)

    if old_hash != new_hash:
        # File is new or changed — update hash
        hash_cache[blob_name] = new_hash
        save_hash_cache(hash_cache)
        return True
    return False
