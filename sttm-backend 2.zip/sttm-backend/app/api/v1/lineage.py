from fastapi import APIRouter, HTTPException, Query
from app.services.lineage_builder import get_lineage_for_table
from app.models.lineage import LineageResponse

router = APIRouter()

@router.get("/", response_model=LineageResponse)
async def get_table_lineage(
    table_name: str = Query(..., description="Target table name to trace lineage")
):
    """
    Returns data lineage for the given table name.
    """
    try:
        lineage = await get_lineage_for_table(table_name)
        if not lineage:
            raise HTTPException(status_code=404, detail="Lineage not found.")
        return {"table": table_name, "lineage": lineage}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
