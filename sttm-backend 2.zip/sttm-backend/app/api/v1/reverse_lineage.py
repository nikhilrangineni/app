from fastapi import APIRouter, HTTPException, Query
from app.services.reverse_lookup import find_reverse_lineage
from typing import List

router = APIRouter()

@router.get("/", response_model=List[str])
async def get_reverse_lineage(
    table_name: str = Query(..., description="Source table to find its dependent target tables")
):
    """
    Returns a list of target tables that depend (directly or indirectly) on the given source table.
    """
    try:
        targets = await find_reverse_lineage(table_name)
        if not targets:
            raise HTTPException(status_code=404, detail="No downstream tables found.")
        return targets
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
