from fastapi import FastAPI
from app.api.v1 import lineage, ddl, reverse_lineage  # add reverse_lineage

app = FastAPI(
    title="CVS STTM WebApp",
    description="Source-to-Target Mapping service for CVS PBM data lineage",
    version="1.0.0"
)

app.include_router(lineage.router, prefix="/api/v1/lineage", tags=["Lineage"])
app.include_router(ddl.router, prefix="/api/v1/ddl", tags=["DDL"])
app.include_router(reverse_lineage.router, prefix="/api/v1/reverse-lineage", tags=["Reverse Lineage"])
