from pydantic import BaseModel
from typing import List, Dict, Optional

class LineageNode(BaseModel):
    table: str
    columns: Optional[List[str]] = []
    sources: Optional[List['LineageNode']] = []

    class Config:
        orm_mode = True
        schema_extra = {
            "example": {
                "table": "CVS_TARGET",
                "columns": ["col1", "col2"],
                "sources": [
                    {
                        "table": "SRC1",
                        "columns": ["colA"],
                        "sources": []
                    },
                    {
                        "table": "SRC2",
                        "columns": ["colB"],
                        "sources": []
                    }
                ]
            }
        }

class LineageResponse(BaseModel):
    table: str
    lineage: LineageNode
