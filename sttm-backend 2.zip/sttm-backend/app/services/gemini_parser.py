import vertexai
from vertexai.preview.generative_models import GenerativeModel

vertexai.init(project="your-project-id", location="us-central1")

model = GenerativeModel("gemini-1.5-pro")

def parse_sql_with_gemini(sql: str) -> dict:
    prompt = f"""
You are an expert data engineer working with BigQuery. Given this SQL, extract:
1. Target table name (insert/update destination)
2. List of source tables
3. Mappings: which column in target comes from which source column

Respond in this JSON format:
{{
  "target": "project.dataset.table",
  "sources": ["project.dataset.table", ...],
  "mappings": [
    {{
      "target_column": "column_name",
      "source_column": "source_table.column_name"
    }}
  ]
}}

SQL:
``` + "\n" + sql

    response = model.generate_content(prompt)
    return response.text
