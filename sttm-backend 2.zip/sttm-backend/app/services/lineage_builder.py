import os
import logging
from typing import Dict, List, Set

from app.models.lineage import LineageNode
from app.services.gcs_scanner import list_sql_files, download_file
from app.services.parser import extract_table_lineage
from app.services.bq_metadata import get_column_metadata
from app.utils.cache import (
    get_cached_lineage,
    add_to_cache,
    is_file_changed
)

# Setup logger
logger = logging.getLogger("lineage")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

# Config
BUCKET_NAME = "your-gcs-bucket-name"
DOWNLOAD_DIR = "temp_sqls"

# In-memory graph: target_table → [source_tables]
lineage_graph: Dict[str, List[str]] = {}


def parse_bq_table_name(full_name: str):
    parts = full_name.split(".")
    if len(parts) == 2:
        return {"project": None, "dataset": parts[0], "table": parts[1]}
    elif len(parts) == 3:
        return {"project": parts[0], "dataset": parts[1], "table": parts[2]}
    else:
        raise ValueError("Invalid BigQuery table format. Use dataset.table or project.dataset.table")


def enrich_node_with_columns(node: LineageNode, project: str = None):
    parts = node.table.split(".")
    if len(parts) == 2:
        dataset, table = parts
    elif len(parts) == 3:
        project, dataset, table = parts
    else:
        return node

    try:
        columns = get_column_metadata(dataset=dataset, table=table, project=project)
        node.columns = [col["name"] for col in columns]
    except Exception as e:
        logger.warning(f"Metadata fetch failed for {node.table}: {e}")
    return node


def build_lineage_graph() -> Dict[str, List[str]]:
    """
    Builds a full target → sources map from all .sql files in GCS.
    Uses Gemini with file change detection.
    """
    logger.info("Scanning GCS and building lineage graph...")
    lineage_map = {}
    files = list_sql_files(BUCKET_NAME)

    for blob_name in files:
        local_path = os.path.join(DOWNLOAD_DIR, blob_name.replace("/", "_"))
        download_file(BUCKET_NAME, blob_name, local_path)

        if not is_file_changed(local_path, blob_name):
            continue  # Skip unchanged files

        try:
            with open(local_path, "r") as f:
                sql = f.read()
                parsed = extract_table_lineage(sql)

                if parsed["target"]:
                    lineage_map[parsed["target"]] = parsed["sources"]
                    logger.info(f"Parsed {blob_name}: {parsed['target']} <- {parsed['sources']}")
        except Exception as e:
            logger.error(f"Failed to parse {blob_name}: {e}")

    return lineage_map


def build_recursive_tree(table: str, visited: Set[str], project: str = None) -> LineageNode:
    """
    Recursively constructs the full lineage tree from the lineage_graph.
    """
    if table in visited:
        return LineageNode(table=table, columns=[], sources=[])  # avoid cycles

    visited.add(table)
    sources = lineage_graph.get(table, [])
    node = LineageNode(
        table=table,
        columns=[],
        sources=[build_recursive_tree(src, visited, project) for src in sources]
    )
    enrich_node_with_columns(node, project)
    return node


async def get_lineage_for_table(table_name: str) -> LineageNode:
    """
    Main API to get full recursive lineage tree for a table.
    """
    bq_table = parse_bq_table_name(table_name)
    normalized_table = f"{bq_table['dataset']}.{bq_table['table']}" if not bq_table["project"] \
        else f"{bq_table['project']}.{bq_table['dataset']}.{bq_table['table']}"

    # Step 1: Load lineage graph if not already
    global lineage_graph
    if not lineage_graph:
        lineage_graph = build_lineage_graph()

    # Step 2: Check if table is in graph
    if normalized_table not in lineage_graph:
        raise ValueError(f"Lineage not found for table: {normalized_table}")

    # Step 3: Build recursive tree
    tree = build_recursive_tree(normalized_table, visited=set(), project=bq_table.get("project"))

    # Step 4: Cache top-level node (optional)
    add_to_cache(
        normalized_table,
        sources=[{"table": src.table, "columns": src.columns} for src in tree.sources]
    )

    return tree
