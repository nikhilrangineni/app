from google.cloud import bigquery

bq_client = bigquery.Client()

def get_column_metadata(dataset: str, table: str, project: str = None):
    """
    Fetches column names and descriptions from BigQuery.
    """
    table_id = f"{project + '.' if project else ''}{dataset}.{table}"
    query = f"""
    SELECT column_name, data_type, description
    FROM `{table_id}.INFORMATION_SCHEMA.COLUMNS`
    WHERE table_name = '{table}'
    """

    results = bq_client.query(query).result()
    return [
        {
            "name": row["column_name"],
            "type": row["data_type"],
            "description": row["description"]
        }
        for row in results
    ]
