import json
from app.services.gemini_parser import parse_sql_with_gemini
import re


def extract_table_lineage(sql: str) -> dict:
    """
    Attempts Gemini parsing first. Falls back to regex if needed.
    """
    try:
        response_text = parse_sql_with_gemini(sql)
        parsed = json.loads(response_text)

        return {
            "target": parsed.get("target"),
            "sources": parsed.get("sources", []),
            "mappings": parsed.get("mappings", [])
        }
    except Exception as e:
        print("[WARN] Gemini failed. Falling back to regex. Error:", e)
        return _regex_fallback_parser(sql)


def _regex_fallback_parser(sql: str) -> dict:
    """
    Simple regex fallback for lineage extraction.
    """
    sql = sql.lower()
    lines = sql.splitlines()
    target = None
    sources = []

    for line in lines:
        if "insert into" in line:
            match = re.search(r"insert into\s+([^\s\(]+)", line)
            if match:
                target = match.group(1)

        for keyword in ["from", "join"]:
            if keyword in line:
                matches = re.findall(fr"{keyword}\s+([^\s;,\)]+)", line)
                sources.extend(matches)

    return {
        "target": target,
        "sources": list(set(sources)),
        "mappings": []
    }
