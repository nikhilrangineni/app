from typing import Dict, Set, List
from app.services.lineage_builder import build_lineage_graph

# Holds reverse dependencies: source → [targets]
reverse_index: Dict[str, List[str]] = {}
lineage_loaded = False


def _invert_graph(lineage_graph: Dict[str, List[str]]) -> Dict[str, List[str]]:
    reverse = {}
    for target, sources in lineage_graph.items():
        for src in sources:
            reverse.setdefault(src, []).append(target)
    return reverse


def _dfs(source: str, graph: Dict[str, List[str]], visited: Set[str], result: Set[str]):
    if source not in graph:
        return
    for target in graph[source]:
        if target not in visited:
            result.add(target)
            visited.add(target)
            _dfs(target, graph, visited, result)


async def find_reverse_lineage(source_table: str) -> List[str]:
    global reverse_index, lineage_loaded

    if not lineage_loaded:
        lineage_graph = build_lineage_graph()
        reverse_index = _invert_graph(lineage_graph)
        lineage_loaded = True

    visited = set()
    result = set()
    _dfs(source_table, reverse_index, visited, result)
    return list(result)
