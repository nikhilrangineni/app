from google.cloud import storage
from typing import List
import os

def list_sql_files(bucket_name: str, prefix: str = "") -> List[str]:
    """
    Lists all .sql files in a GCS bucket (optionally under a prefix/folder).
    """
    client = storage.Client()
    bucket = client.bucket(bucket_name)
    blobs = bucket.list_blobs(prefix=prefix)

    sql_files = [blob.name for blob in blobs if blob.name.endswith(".sql")]
    return sql_files

def download_file(bucket_name: str, blob_name: str, local_path: str):
    """
    Downloads a GCS blob to a local file path.
    """
    os.makedirs(os.path.dirname(local_path), exist_ok=True)
    client = storage.Client()
    bucket = client.bucket(bucket_name)
    blob = bucket.blob(blob_name)
    blob.download_to_filename(local_path)
