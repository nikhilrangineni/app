export async function getLineageForTable(tableName: string) {
    const url = `http://localhost:8000/api/v1/lineage?table_name=${encodeURIComponent(tableName)}`
    const res = await fetch(url)
  
    if (!res.ok) {
      const text = await res.text()
      throw new Error(`API Error (${res.status}): ${text}`)
    }
  
    return await res.json()
  }
  