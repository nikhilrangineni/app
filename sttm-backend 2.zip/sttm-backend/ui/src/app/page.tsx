"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"
import { getLineageForTable } from "@/lib/utils"
import LineageGraph from "@/components/LineageGraph"

export default function HomePage() {
  const [table, setTable] = useState("")
  const [loading, setLoading] = useState(false)
  const [lineage, setLineage] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)

  const handleTrace = async () => {
    setLoading(true)
    setError(null)
    setLineage(null)

    try {
      const result = await getLineageForTable(table)
      setLineage(result)
    } catch (err: any) {
      setError(err.message || "Something went wrong")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen p-6 bg-gray-50">
      <h1 className="text-2xl font-semibold mb-4">CVS PBMEDH Lineage Explorer</h1>

      <div className="flex gap-2 items-center mb-4">
        <Input
          placeholder="Enter BigQuery table (e.g., pbmedh_stage.claims_detail)"
          value={table}
          onChange={(e) => setTable(e.target.value)}
          className="w-[400px]"
        />
        <Button onClick={handleTrace} disabled={loading}>
          {loading ? <Loader2 className="animate-spin h-4 w-4" /> : "Trace Lineage"}
        </Button>
      </div>

      {error && <div className="text-red-600 font-medium mb-2">{error}</div>}

      {lineage && <LineageGraph lineage={lineage} />}
    </main>
  )
}
