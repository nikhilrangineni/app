"use client"

import React, { useEffect, useState } from "react"
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  Node,
  Edge,
  Position,
} from "reactflow"
import "reactflow/dist/style.css"
import { ChevronDown, ChevronUp } from "lucide-react"

type LineageNodeType = {
  table: string
  columns?: string[]
  sources?: LineageNodeType[]
}

type Props = {
  lineage: LineageNodeType
}

let nodeIdCounter = 1
const generateNodeId = () => `node-${nodeIdCounter++}`

// 🎨 LM-inspired pastel edge colors
const edgeColors = [
  "#4f46e5", // Indigo
  "#06b6d4", // Cyan
  "#22c55e", // Green
  "#ec4899", // Pink
  "#f59e0b", // Amber
  "#8b5cf6", // Violet
]

const getRandomColor = () =>
  edgeColors[Math.floor(Math.random() * edgeColors.length)]

export default function LineageGraph({ lineage }: Props) {
  const [nodes, setNodes, onNodesChange] = useNodesState([])
  const [edges, setEdges, onEdgesChange] = useEdgesState([])
  const [expanded, setExpanded] = useState<Record<string, boolean>>({})

  useEffect(() => {
    if (!lineage) return

    nodeIdCounter = 1 // reset ID counter
    const seen = new Map<string, string>()
    const nodes: Node[] = []
    const edges: Edge[] = []

    const buildGraph = (node: LineageNodeType, parentId?: string) => {
      const key = node.table.toLowerCase()
      const nodeId = seen.get(key) || generateNodeId()

      if (!seen.has(key)) {
        seen.set(key, nodeId)
        const isExpanded = expanded[nodeId] ?? false
        nodes.push({
          id: nodeId,
          data: {
            label: (
              <div className="text-left p-2">
                <div className="flex justify-between items-center">
                  <span className="font-medium">{node.table}</span>
                  {node.columns && node.columns.length > 0 && (
                    <button
                      className="text-xs text-blue-600"
                      onClick={(e) => {
                        e.stopPropagation()
                        setExpanded((prev) => ({
                          ...prev,
                          [nodeId]: !prev[nodeId],
                        }))
                      }}
                    >
                      {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                    </button>
                  )}
                </div>
                {isExpanded && node.columns && (
                  <ul className="text-xs mt-1 max-h-[120px] overflow-auto pr-1">
                    {node.columns.map((col) => (
                      <li key={col} className="text-gray-700">• {col}</li>
                    ))}
                  </ul>
                )}
              </div>
            ),
          },
          position: { x: Math.random() * 300, y: Math.random() * 300 },
          sourcePosition: Position.Right,
          targetPosition: Position.Left,
          style: {
            border: "1px solid #ccc",
            borderRadius: 12,
            padding: 6,
            backgroundColor: "#fff",
            width: 220,
          },
        })
      }

      if (parentId) {
        edges.push({
          id: `e-${nodeId}-${parentId}`,
          source: nodeId,
          target: parentId,
          animated: true,
          style: {
            stroke: getRandomColor(),
            strokeWidth: 2,
          },
        })
      }

      node.sources?.forEach((src) => buildGraph(src, nodeId))
    }

    buildGraph(lineage)

    setNodes(nodes)
    setEdges(edges)
  }, [lineage, expanded])

  return (
    <div className="w-full h-[700px] border rounded-md bg-white shadow">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        fitView
      >
        <MiniMap />
        <Controls />
        <Background />
      </ReactFlow>
    </div>
  )
}
