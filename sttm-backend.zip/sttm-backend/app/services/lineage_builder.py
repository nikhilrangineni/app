from app.models.lineage import LineageNode

async def get_lineage_for_table(table_name: str) -> LineageNode:
    # Placeholder: In future steps we'll load from cache or parse GCS
    return LineageNode(
        table=table_name,
        columns=["dummy_col1", "dummy_col2"],
        sources=[
            LineageNode(table="SRC_TABLE_1", columns=["src_col1"], sources=[]),
            LineageNode(table="SRC_TABLE_2", columns=["src_col2"], sources=[])
        ]
    )
